#ifndef MODULE_NEWCAMD_H_
#define MODULE_NEWCAMD_H_

const char *newcamd_get_client_name(uint16_t client_id);

#endif
