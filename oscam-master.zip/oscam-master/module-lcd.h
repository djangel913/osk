#ifndef MODULE_LCD_H_
#define MODULE_LCD_H_

#ifdef LCDSUPPORT
extern void lcd_thread_start(void);
extern void lcd_thread_stop(void);
#else
static inline void lcd_thread_start(void) { }
static inline void lcd_thread_stop(void) { }
#endif

#endif
